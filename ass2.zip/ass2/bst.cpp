//
// Created by bazen on 1/26/2019.
//

#include "bst.h"
#include <iostream>